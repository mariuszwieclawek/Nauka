#ifndef leds_h
#define leds_h


void ledsInitialize(void);

void fsmStartStop(void);
void fsmFastSlow(void);
void fsmService(void);

#endif
