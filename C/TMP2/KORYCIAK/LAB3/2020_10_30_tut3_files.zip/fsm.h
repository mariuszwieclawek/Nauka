#ifndef fsm_h
#define fsm_h


void fsmInitialize(void);

void fsmStartStop(void);
void fsmFastSlow(void);
void fsmOneMSService(void);

#endif
