#ifndef pit_h
#define pit_h


void pitInitialize(unsigned period);
void startPIT(void);
void stopPIT(void);


#endif
