#include "MKL05Z4.h"

void DAC_Init(void);
uint8_t DAC_Load_Trig(uint16_t load);
